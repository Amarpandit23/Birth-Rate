const api = "https://api.worldbank.org/v2/country/all/indicator/SP.DYN.CBRT.IN?format=json&per_page=1000";
const geoURL = "https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson";

// Tooltip
const tooltip = d3.select("body").append("div")
  .attr("class", "tooltip");

d3.json(api).then(res => {
  const data = res[1].filter(d =>
    d.date === "2020" &&
    d.value &&
    d.country &&
    /^[A-Z]{3}$/.test(d.country.id)
  );

  const birthRateMap = {};
  const countryNameMap = {};
  data.forEach(d => {
    birthRateMap[d.country.id] = d.value;
    countryNameMap[d.country.id] = d.country.value;
  });

  d3.json(geoURL).then(geo => {
    const width = 1000, height = 550;

    const svg = d3.select("#chart").append("svg")
      .attr("width", width).attr("height", height);

    const projection = d3.geoNaturalEarth1().scale(160).translate([width / 2, height / 2]);
    const path = d3.geoPath().projection(projection);

    const color = d3.scaleSequential().domain([10, 50]).interpolator(d3.interpolateOranges);

    const countries = svg.append("g")
      .selectAll("path")
      .data(geo.features)
      .enter().append("path")
      .attr("d", path)
      .attr("fill", d => {
        const rate = birthRateMap[d.id];
        return rate ? color(rate) : "#eee";
      })
      .attr("stroke", "#fff")
      .attr("stroke-width", 0.7)
      .on("mouseover", (event, d) => {
        const rate = birthRateMap[d.id];
        tooltip.transition().duration(200).style("opacity", 0.9);
        tooltip.html(`<strong>${countryNameMap[d.id] || d.properties.name}</strong><br>Birth Rate: ${rate || "N/A"}`)
          .style("left", (event.pageX + 10) + "px")
          .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", () => {
        tooltip.transition().duration(300).style("opacity", 0);
      });

    // Legend
    const legendWidth = 300, legendHeight = 10;
    const defs = svg.append("defs");
    const gradient = defs.append("linearGradient")
      .attr("id", "linear-gradient");

    gradient.selectAll("stop")
      .data(color.ticks().map((t, i, n) => ({
        offset: `${100 * i / n.length}%`,
        color: color(t)
      })))
      .enter().append("stop")
      .attr("offset", d => d.offset)
      .attr("stop-color", d => d.color);

    svg.append("g")
      .attr("transform", `translate(${width - legendWidth - 60}, ${height - 40})`)
      .append("rect")
      .attr("width", legendWidth)
      .attr("height", legendHeight)
      .style("fill", "url(#linear-gradient)");

    svg.append("g")
      .attr("transform", `translate(${width - legendWidth - 60}, ${height - 25})`)
      .call(d3.axisBottom(d3.scaleLinear().domain(color.domain()).range([0, legendWidth])).ticks(5))
      .select(".domain").remove();

    // Search
    const input = document.getElementById("search-country");
    input.addEventListener("input", () => {
      const query = input.value.trim().toUpperCase();
      countries.attr("stroke", d => d.id === query ? "#000" : "#fff")
               .attr("stroke-width", d => d.id === query ? 2 : 0.7);
    });
  });
});