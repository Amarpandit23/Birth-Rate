d3.json("https://api.worldbank.org/v2/country/all/indicator/SP.DYN.CBRT.IN?format=json&per_page=1000").then(res => {
    const data = res[1].filter(d => d.date === "2020" && d.value !== null).slice(0, 30);
  
    const width = 800, height = 600;
    const svg = d3.select("#chart").append("svg").attr("width", width).attr("height", height);
  
    const scale = d3.scaleSqrt()
      .domain([0, d3.max(data, d => d.value)])
      .range([10, 50]);
  
    const simulation = d3.forceSimulation(data)
      .force("charge", d3.forceManyBody().strength(5))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius(d => scale(d.value) + 2))
      .on("tick", ticked);
  
    // inside ticked() function
function ticked() {
  const circles = svg.selectAll("circle").data(data);

  circles.enter()
    .append("circle")
    .attr("r", d => scale(d.value))
    .attr("fill", "#00bcd4")
    .merge(circles)
    .attr("cx", d => d.x)
    .attr("cy", d => d.y);

  circles.exit().remove();

  // ADD TEXT LABELS
  const labels = svg.selectAll("text").data(data);

  labels.enter()
    .append("text")
    .text(d => d.country.value) // or use d.value if you want the birth rate
    .style("font-size", "10px")
    .style("fill", "black")
    .style("text-anchor", "middle")
    .merge(labels)
    .attr("x", d => d.x)
    .attr("y", d => d.y + 4); // slightly lower to center-align text

  labels.exit().remove();
}
});