const url = "https://api.worldbank.org/v2/country/all/indicator/SP.DYN.CBRT.IN?format=json&per_page=10000";

d3.json(url).then(res => {
  const raw = res[1];

  const countries = ["India", "United States", "Brazil"];
  const filtered = raw.filter(d => 
    d.country && countries.includes(d.country.value) &&
    d.value !== null && d.date >= "2000" // Filter recent only
  );

  const grouped = d3.groups(filtered, d => d.country.value);

  const lineData = grouped.map(([country, values]) => ({
    country,
    values: values
      .sort((a, b) => +a.date - +b.date)
      .map(d => ({ year: +d.date, value: +d.value }))
  }));

  const margin = { top: 50, right: 100, bottom: 50, left: 60 },
        width = 800 - margin.left - margin.right,
        height = 500 - margin.top - margin.bottom;

  const svg = d3.select("#chart").append("svg")
    .attr("viewBox", `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
    .attr("preserveAspectRatio", "xMidYMid meet")
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.scaleLinear().domain([2000, 2020]).range([0, width]);
  const y = d3.scaleLinear()
    .domain([0, d3.max(lineData.flatMap(d => d.values), d => d.value)])
    .range([height, 0]);

  const color = d3.scaleOrdinal(d3.schemeCategory10);

  svg.append("g").call(d3.axisLeft(y));
  svg.append("g")
    .attr("transform", `translate(0, ${height})`)
    .call(d3.axisBottom(x).tickFormat(d3.format("d")));

  const line = d3.line().x(d => x(d.year)).y(d => y(d.value));

  svg.selectAll(".line")
    .data(lineData)
    .enter()
    .append("path")
    .attr("fill", "none")
    .attr("stroke", d => color(d.country))
    .attr("stroke-width", 2)
    .attr("d", d => line(d.values))
    .attr("stroke-dasharray", function () {
      return `${this.getTotalLength()} ${this.getTotalLength()}`;
    })
    .attr("stroke-dashoffset", function () {
      return this.getTotalLength();
    })
    .transition()
    .duration(2000)
    .attr("stroke-dashoffset", 0);
});