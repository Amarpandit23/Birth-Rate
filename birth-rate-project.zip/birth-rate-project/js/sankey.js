const data = {
    nodes: [
      { name: "Africa" }, { name: "Asia" }, { name: "Europe" },
      { name: "Low Income" }, { name: "Middle Income" }, { name: "High Income" }
    ],
    links: [
      { source: 0, target: 3, value: 40 },
      { source: 1, target: 4, value: 60 },
      { source: 2, target: 5, value: 30 },
      { source: 0, target: 4, value: 10 },
      { source: 1, target: 5, value: 10 }
    ]
  };
  
  const width = 700, height = 400;
  
  const svg = d3.select("#chart").append("svg")
    .attr("width", width)
    .attr("height", height);
  
  const sankey = d3.sankey()
    .nodeWidth(20)
    .nodePadding(20)
    .extent([[1, 1], [width - 1, height - 6]]);
  
  const graph = sankey(data);
  
  // Tooltip
  const tooltip = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("position", "absolute")
    .style("background", "#333")
    .style("color", "#fff")
    .style("padding", "5px")
    .style("border-radius", "5px")
    .style("opacity", 0);
  
  // Nodes
  svg.append("g")
    .selectAll("rect")
    .data(graph.nodes)
    .join("rect")
    .attr("x", d => d.x0)
    .attr("y", d => d.y0)
    .attr("height", d => d.y1 - d.y0)
    .attr("width", d => d.x1 - d.x0)
    .attr("fill", "#607d8b")
    .attr("stroke", "#000");
  
  // Node Labels
  svg.append("g")
    .selectAll("text")
    .data(graph.nodes)
    .join("text")
    .attr("x", d => d.x0 - 6)
    .attr("y", d => (d.y1 + d.y0) / 2)
    .attr("dy", "0.35em")
    .attr("text-anchor", "end")
    .text(d => d.name);
  
  // Links (flows)
  svg.append("g")
    .attr("fill", "none")
    .selectAll("path")
    .data(graph.links)
    .join("path")
    .attr("d", d3.sankeyLinkHorizontal())
    .attr("stroke", "#90caf9")
    .attr("stroke-width", d => Math.max(1, d.width))
    .on("mouseover", (event, d) => {
      tooltip.transition().duration(200).style("opacity", 0.9);
      tooltip.html(`${d.source.name} → ${d.target.name}<br>Value: ${d.value}`)
        .style("left", event.pageX + "px")
        .style("top", event.pageY - 28 + "px");
    })
    .on("mouseout", () => {
      tooltip.transition().duration(500).style("opacity", 0);
    });
  
  // Optional: Link labels (positioned mid-path)
  svg.append("g")
    .selectAll("text.link-label")
    .data(graph.links)
    .join("text")
    .attr("class", "link-label")
    .attr("x", d => (d.source.x1 + d.target.x0) / 2)
    .attr("y", d => (d.y0 + d.y1) / 2)
    .attr("text-anchor", "middle")
    .attr("font-size", "10px")
    .text(d => d.value);