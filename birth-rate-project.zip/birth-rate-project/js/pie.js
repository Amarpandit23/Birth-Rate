const apiUrl = "https://api.worldbank.org/v2/country/all/indicator/SP.DYN.CBRT.IN?format=json&per_page=10000";

const regionMap = {
  "India": "Asia", "China": "Asia", "Japan": "Asia",
  "United States": "North America", "Canada": "North America",
  "Brazil": "South America", "Argentina": "South America",
  "Nigeria": "Africa", "Kenya": "Africa",
  "Germany": "Europe", "France": "Europe"
};

d3.json(apiUrl).then(res => {
  const raw = res[1];

  const filtered = raw.filter(d => 
    d.date === "2020" && d.value !== null && regionMap[d.country.value]
  );

  const regionSums = d3.rollups(filtered, v => d3.sum(v, d => d.value), d => regionMap[d.country.value]);

  const width = 500, height = 500, radius = Math.min(width, height) / 2;

  const svg = d3.select("#chart")
    .append("svg")
    .attr("viewBox", `0 0 ${width} ${height}`)
    .attr("preserveAspectRatio", "xMidYMid meet")
    .append("g")
    .attr("transform", `translate(${width/2}, ${height/2})`);

  const pie = d3.pie().value(d => d[1]);
  const arc = d3.arc().innerRadius(0).outerRadius(radius);
  const color = d3.scaleOrdinal(d3.schemeSet2);

  const arcs = svg.selectAll("arc")
    .data(pie(regionSums))
    .enter()
    .append("g");

  arcs.append("path")
    .attr("fill", d => color(d.data[0]))
    .transition()
    .duration(1000)
    .attrTween("d", function(d) {
      const i = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
      return t => arc(i(t));
    });

  arcs.append("text")
    .attr("transform", d => `translate(${arc.centroid(d)})`)
    .attr("text-anchor", "middle")
    .text(d => d.data[0]);
});